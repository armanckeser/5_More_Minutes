﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SongManager : MonoBehaviour {

    public AudioClip realWorld;
    public AudioClip dreamWorld;
    public GameController myController;

    private AudioSource audioSource;
    private AudioSource as2;
    private AudioSource active;
    private AudioClip playingClip;

	// Use this for initialization
	void Start () {
		if ((realWorld == null) || (dreamWorld == null))
        {
            string error = "";
            if (realWorld == null)
                error = "The Real World Audio Clip has not been initialized in the inspector, please do this now.";
            if (dreamWorld == null)
                error += "The Dream World Audio Clip has not been initialized in the inspector, please do this now.";
            Debug.LogError(error);
        }


        if (audioSource == null || as2 == null)
        {
            Debug.LogWarning("AudioSource component missing from this gameobject. Adding one.");
            audioSource = gameObject.AddComponent<AudioSource>();
            as2 = gameObject.AddComponent<AudioSource>();
        }
        audioSource.loop = true;
        as2.loop = true;
        audioSource.clip = realWorld;
        as2.clip = dreamWorld;
        audioSource.Play();
        as2.Play();
        as2.Pause();
        active = audioSource;
	}

    public void switchMusic()
    {
        Debug.Log(audioSource.loop);
        if(active==audioSource)
        {
            audioSource.Pause();
            active = as2;
            as2.UnPause();
        }
        else
        {
            as2.Pause();
            active = audioSource;
            audioSource.UnPause();
        }

    }
	// Update is called once per frame
	void Update () {
        bool a = myController.inRealWorld;
        bool b = active == audioSource;
		if(a&&!b || b&&!a)
        {
            switchMusic();
        }
	}
}
