﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {

    public float xSpeed, ySpeed;
    public float xAccel, yAccel;
    public float damage;
	// Use this for initialization
	protected void Start () {
        
	}
	
	// Update is called once per frame
	protected void Update () {
        float dt = Time.deltaTime;
        transform.Translate(xSpeed * dt, ySpeed * dt, 0, Space.Self);
        xSpeed += xAccel * dt;
        ySpeed += yAccel * dt;
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Projectile p = collision.gameObject.GetComponent<Projectile>();
        if(p != null)
        {
            Destroy(p.gameObject);
            Destroy(this.gameObject);
        }
    }


}
