﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour {

    private double swordAngle = 0;
    private double rotateRate = 90;
    public GameObject mySword;
	// Use this for initialization
	void Start () {
        swordAngle = 0;
        swordAngle += Time.deltaTime * rotateRate;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
