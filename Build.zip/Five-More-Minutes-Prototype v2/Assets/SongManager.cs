﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SongManager : MonoBehaviour {

    public AudioClip realWorld;
    public AudioClip dreamWorld;
    public GameController myController;

    private AudioSource audioSource;
    private AudioClip playingClip;

	// Use this for initialization
	void Start () {
		if ((realWorld == null) || (dreamWorld == null))
        {
            string error = "";
            if (realWorld == null)
                error = "The Real World Audio Clip has not been initialized in the inspector, please do this now.";
            if (dreamWorld == null)
                error += "The Dream World Audio Clip has not been initialized in the inspector, please do this now.";
            Debug.LogError(error);
        }

        audioSource = gameObject.GetComponent<AudioSource>();
        if (audioSource == null)
        {
            Debug.LogWarning("AudioSource component missing from this gameobject. Adding one.");
            audioSource = gameObject.AddComponent<AudioSource>();
        }
        PlayRealWorld();
	}
	
    public void PlayRealWorld()
    {
        audioSource.Stop();
        audioSource.loop = true;
        audioSource.PlayOneShot(realWorld);
        playingClip = realWorld;
    }

    public void PlayDreamWorld()
    {
        audioSource.Stop();
        audioSource.loop = true;
        audioSource.PlayOneShot(dreamWorld);
        playingClip = dreamWorld;
    }

	// Update is called once per frame
	void Update () {
		if (myController.inRealWorld == false)
        {
            PlayDreamWorld();
        }
        else
        {
            if ((playingClip == dreamWorld) && (audioSource.isPlaying))
            {
                PlayRealWorld();
            }
        }
	}
}
