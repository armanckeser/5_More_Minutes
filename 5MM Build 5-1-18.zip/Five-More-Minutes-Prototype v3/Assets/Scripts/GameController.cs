﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameController : MonoBehaviour {

    public Camera realCamera;
    public Player myPlayer;
    int score;
    float secondsLasted;
    bool lost;
    public bool inRealWorld;
    float worldJumpSeconds = 0;
    int moveDirection = 1;
    public RawImage minimap;
    public Camera minimapCamera;
    public ArrayList activeMonsters;
    public Heart heart;

	// Use this for initialization
	void Start () {
        realCamera.enabled = true;
        inRealWorld = true;
        secondsLasted = score = 0;
        lost = false;
        activeMonsters = new ArrayList();
	}

    public void lose()
    {
        lost = true;
        SceneManager.LoadScene("Title Screen", LoadSceneMode.Single);
    }

    public bool gameOver()
    {
        return lost;
    }

    // Update is called once per frame
    void Update() {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
        if(Input.GetKeyDown(KeyCode.E))
        {
            myPlayer.activateSpeedBoost();
        }
        if(Input.GetKeyDown(KeyCode.F))
        {
            myPlayer.multiShot();
        }
        if (worldJumpSeconds == 0)
        {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (inRealWorld)
            {
                myPlayer.transform.Translate(100, 100, 0, Space.World);
                inRealWorld = false;
                moveDirection = 1;
                for(int i = 0; i < activeMonsters.Count; i++)
                {
                        Monster m = (Monster)activeMonsters[i];
                        m.target = heart.gameObject;
                }
            }
            else
            {
                    //realCamera.transform.Translate(-100, -100, 0, Space.World);
                realCamera.transform.position = new Vector3(100, 100, realCamera.transform.position.z);

                myPlayer.transform.Translate(-100, -100, 0, Space.World);
                inRealWorld = true;
                moveDirection = -1;
            }
            myPlayer.disableMovement();
            worldJumpSeconds = 0.5f;
        }
        if(!inRealWorld)
        {
                //realCamera.transform.position = new Vector3(myPlayer.transform.position.x, myPlayer.transform.position.y, realCamera.transform.position.z);
        }
        }
        else
        {
            worldJumpSeconds -= Time.deltaTime;
            float f = 200 * Time.deltaTime;
            realCamera.transform.Translate(f * moveDirection, f * moveDirection, 0, Space.World);
            minimapCamera.transform.Translate(-1 * f * moveDirection, -1 * f * moveDirection, 0, Space.World);
            if (worldJumpSeconds < 0)
            {
                realCamera.transform.Translate(worldJumpSeconds * 200 * moveDirection, worldJumpSeconds * 200 * moveDirection, 0, Space.World);
                minimapCamera.transform.Translate(worldJumpSeconds * -200 * moveDirection, worldJumpSeconds * -200 * moveDirection, 0, Space.World);
                worldJumpSeconds = 0;
            }
                
        }
        if (!lost)
        {
            secondsLasted += Time.deltaTime;
        }
        else
        {

        }
	}
}
