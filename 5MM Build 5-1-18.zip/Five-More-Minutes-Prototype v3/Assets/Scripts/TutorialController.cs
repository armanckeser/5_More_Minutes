﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TutorialController : MonoBehaviour {


    float returnCooldown = 0;
    int stage;
    public Text activeText;
    public Text[] texts;
    public SpriteRenderer room;
    public Player pl;
    public Alarm myAlarm;
    public Monster m1, m2;
    public Heart myHeart;
    public RawImage minimap;
	// Use this for initialization
	void Start () {
        stage = 0;
        activeText = texts[stage];
        activeText.GetComponent<ScrollingText>().isOn = true;
        myAlarm.detonationTime = 20;
        myAlarm.initialCooldown = 15;
        myAlarm.enabled = false;
        myAlarm.gameObject.GetComponent<SpriteRenderer>().enabled = false;
        m1.enabled = false;
        m2.enabled = false;
        //minimap.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
        returnCooldown -= Time.deltaTime;
		if(Input.GetKey(KeyCode.Return) && returnCooldown <= 0)
        {
            activeText.GetComponent<ScrollingText>().isOn = false;
            stage++;
            if(stage == 5)
            {
                minimap.enabled = true;
                myAlarm.initialCooldown = 20;
                m1.initialWait = 20;
                m2.initialWait = 20;
                m2.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                m1.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                m1.enabled = true;
                m2.enabled = true;
                myAlarm.enabled = true;
                myHeart.enabled = true;
                myHeart.GetComponent<SpriteRenderer>().enabled = true;
                myHeart.GetComponent<CircleCollider2D>().enabled = true;
            }
            if(stage == 6)
            {
                SceneManager.LoadScene("Title Screen", LoadSceneMode.Single);
            }
            activeText = texts[stage];
            activeText.GetComponent<ScrollingText>().isOn = true;
            returnCooldown = 0.5f;
        }
        if(Input.GetKey(KeyCode.Backspace))
        {
            SceneManager.LoadScene("Title Screen", LoadSceneMode.Single);
        }
        if(stage==0)
        {

        }
        else if(stage==1)
        {
            room.enabled = true;
            pl.enabled = true;
            pl.gameObject.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if(stage==2)
        {
            myAlarm.enabled = true;
        }
        else if(stage == 3)
        {
            myAlarm.enabled = false;
            myAlarm.gameObject.GetComponent<SpriteRenderer>().enabled = false;
        }
        else if(stage == 4)
        {
           
        }
        else if(stage == 5)
        {
        
        }
    }
}
