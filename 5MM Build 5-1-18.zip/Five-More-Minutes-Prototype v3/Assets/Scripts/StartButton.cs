﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartButton : MonoBehaviour {
	// Use this for initialization
	void Start () {
       
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void startGame()
    {
        SceneManager.LoadScene("GameScene", LoadSceneMode.Single);
    }

    public void startTutorial()
    {
        SceneManager.LoadScene("Tutorial", LoadSceneMode.Single);
    }
}
