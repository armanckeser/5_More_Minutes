﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Heart : MonoBehaviour {

    private float health = 100;
    public Sprite[] images;
    public GameController myController;
	// Use this for initialization
	void Start () {
        switchImage();
	}

    public void reduceHealth(float reduction)
    {
        health -= reduction;
        if(health < 0)
        {
            myController.lose();
        }
        switchImage();

    }

    void switchImage()
    {
        int imageNum = 6 - (int)((health-0.001) * 7 / 100);
        Sprite currentImage = images[imageNum];
        GetComponent<SpriteRenderer>().sprite = currentImage;
    }
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Projectile p = collision.gameObject.GetComponent<Projectile>();
        if(p!=null)
        {
            if(p.shooter.GetComponent<Player>() == null)
            {
                reduceHealth(p.damage);
            }

            Destroy(p.gameObject);
        }
    }
}
