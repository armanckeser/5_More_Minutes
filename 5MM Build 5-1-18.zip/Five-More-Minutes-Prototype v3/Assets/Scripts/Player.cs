﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public GameController myController;
    public Projectile projectile;
    float speed = 0.1f;
    public float activeCooldown;
    float fireCooldown = 0f;
    float moveWait = 0f;
    public float HP;
    public float myDamage;
    public float speedBoostActivity = 0;
    public float speedBoostCooldown = 0;
    public float angle;
    public float multiShotCooldown = 0;
    //public int alarmJammers;
    // Use this for initialization
    void Start()
    {
        transform.Translate(0, 0, 0);
    }
    public void disableMovement()
    {
        moveWait = 0.5f;
    }
        // Update is called once per frame
    void Update () {
        if(speedBoostActivity != 0)
            speedBoostActivity -= Time.deltaTime;
        if(speedBoostActivity < 0)
        {
            speedBoostActivity = 0;
            speed /= 2;
        }
        if (multiShotCooldown > 0)
            multiShotCooldown -= Time.deltaTime;
        speedBoostCooldown -= Time.deltaTime;
        fireCooldown -= Time.deltaTime;
        moveWait -= Time.deltaTime;
        if (moveWait <= 0)
        {
            if (Input.GetKey(KeyCode.W))
            {
                transform.Translate(new Vector3(0, speed, 0), Space.World);
            }
            if (Input.GetKey(KeyCode.A))
            {
                transform.Translate(new Vector3(-1 * speed, 0, 0), Space.World);
            }
            if (Input.GetKey(KeyCode.S))
            {
                transform.Translate(new Vector3(0, -1 * speed, 0), Space.World);
            }
            if (Input.GetKey(KeyCode.D))
            {
                transform.Translate(new Vector3(speed, 0, 0), Space.World);
            }

            Vector3 mousePos = new Vector3(Input.mousePosition.x, Input.mousePosition.y, Input.mousePosition.z);
            Vector3 lookPos = Camera.main.ScreenToWorldPoint(mousePos);
            lookPos = lookPos - transform.position;
            angle = Mathf.Atan2(lookPos.y, lookPos.x) * Mathf.Rad2Deg;
            //myController.getActiveCamera().transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
            transform.rotation = Quaternion.AngleAxis(angle - 90.0f, Vector3.forward);
        }
        
        if(Input.GetMouseButton(0) && fireCooldown <= 0 && !myController.inRealWorld)
        {
            fire();
        }
    }

    public void fire()
    {
        Projectile newProjectile = Instantiate(projectile);
        newProjectile.shooter = this.gameObject;
        newProjectile.transform.SetPositionAndRotation(GetComponent<Transform>().position, GetComponent<Transform>().rotation);
        newProjectile.transform.Translate(0, 1.0f, 0, Space.Self);
        newProjectile.xSpeed = 0.0f;
        newProjectile.ySpeed = 20.0f;
        newProjectile.xAccel = 0;
        newProjectile.yAccel = 0;
        newProjectile.damage = myDamage;
        fireCooldown = activeCooldown;
    }

    public void multiShot()
    {
        if (multiShotCooldown <= 0)
        {
            fire();
            angle += 20;
            transform.rotation = Quaternion.AngleAxis(angle - 90.0f, Vector3.forward);
            fire();
            angle -= 40;
            transform.rotation = Quaternion.AngleAxis(angle - 90.0f, Vector3.forward);
            fire();
            angle += 20;
            transform.rotation = Quaternion.AngleAxis(angle - 90.0f, Vector3.forward);

            multiShotCooldown = 5;
        }
    }

    public void takeDamage(float damage)
    {
        HP -= damage;
        if(HP <= 0)
        {
            myController.lose();
        }
    }

    public void activateSpeedBoost()
    {
        if (speedBoostCooldown < 0)
        {
            speed *= 2;
            speedBoostActivity = 5;
            speedBoostCooldown = 25;
        }
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {
        Projectile p = collision.gameObject.GetComponent<Projectile>();
        if(p!=null)
        {
            takeDamage(p.damage);
            Destroy(p.gameObject);
        }
        
    }
}
