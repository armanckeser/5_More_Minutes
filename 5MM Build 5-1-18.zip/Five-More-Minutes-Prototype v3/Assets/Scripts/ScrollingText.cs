﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScrollingText : MonoBehaviour {

    string text;
    float timeElapsed;
    int textLen;
    public float speed;
    public bool isOn;
    public float initialDelay;

	// Use this for initialization
	void Start () {
        text = GetComponent<Text>().text;
        GetComponent<Text>().text = "";
        textLen = text.Length;
	}
	
	// Update is called once per frame
	void Update () {
        if (isOn)
        {
            timeElapsed += Time.deltaTime;
            if (timeElapsed > speed * textLen)
                GetComponent<Text>().text = text;
            else
                GetComponent<Text>().text = text.Substring(0, (int)(timeElapsed / speed));
        }
        else if(initialDelay > 0)
        {
            initialDelay -= Time.deltaTime;
            if(initialDelay <= 0)
            {
                initialDelay = 0;
                isOn = true;
            }
        }
        if(!isOn)
        {
            GetComponent<Text>().text = "";
        }
	}
}
