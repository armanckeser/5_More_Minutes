﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour {

    public GameController myController;
    float timeCounter;
    SpriteRenderer myRenderer;
    public float detonationTime;
    public float moveSpeed = 100;
    public bool canMove;
    float xSpeed = 0f, ySpeed = 0f;
    public Target template;
    // Use this for initialization
    void Start()
    {
        timeCounter = 0.0f;
        myRenderer = GetComponent<SpriteRenderer>();
        setColor();
        //set sprite's color to green
    }

    // Update is called once per frame
    void Update()
    {
        if (canMove)
        {
            timeCounter += Time.deltaTime;
            xSpeed += Random.Range(-.1f, .1f);
            ySpeed += Random.Range(-.1f, .1f);
            transform.Translate(new Vector3(xSpeed * Time.deltaTime, ySpeed * Time.deltaTime, 0));
            setColor();
        }
        
    }

    void setColor()
    {
        if (timeCounter >= detonationTime)
        {
            myController.lose();
            timeCounter = detonationTime;
        }
        float red = timeCounter / detonationTime;
        float green = (detonationTime - timeCounter) / detonationTime;
        float blue = 0.0f;
        myRenderer.color = new Color(red, green, blue);
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        Projectile p = col.gameObject.GetComponent<Projectile>();
        if(p!=null)
        {
            timeCounter = 0.0f;
            detonationTime -= 0.1f;
            setColor();
            Destroy(col.gameObject);
            //Target t = Instantiate(template);
            //t.transform.position = new Vector3(100, 100, 0);
            //t.canMove = true;
            //float f = Random.Range(0.05f, 0.25f);
            //t.transform.localScale = new Vector3(f, f, 1);
            //t.detonationTime = detonationTime;
            Destroy(gameObject);
        }       
    }


}
