﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour {

    public Projectile myProjectile;
    public GameObject target;
    public Heart persistentTarget;
    public GameController myController;
    public float pursuitFraction;
    public float coolDown;
    public float coolDownActive;
    public float initialWait;
    public float hp;
    public float projectileDamage;
    public float projectileSpeed;
    public Vector2 projectileCurve;
    public bool isMirror;
    bool mirrorActive;
    public float mirrorOnTime;
    public float mirrorOffTime;
    float mirrorCounter = 0f;

    // Use this for initialization
    protected void Start () {
        coolDownActive = coolDown;
        persistentTarget = target.GetComponent<Heart>();
        if (isMirror)
        {
            mirrorActive = true;
            gameObject.GetComponent<SpriteRenderer>().color = new Color(0.25f, 0.25f, 0.25f);
        }
	}

    public void takeDamage(float dmg)
    {
        hp -= dmg;
        if(hp < 0)
        {
            Destroy(this.gameObject);
        }
    }
	// Update is called once per frame
	protected void Update () {
        if (initialWait > 0)
        {
            GetComponent<SpriteRenderer>().enabled = false;
            GetComponent<CapsuleCollider2D>().enabled = false;
            initialWait -= Time.deltaTime;
        }
        else 
        {
            GetComponent<SpriteRenderer>().enabled = true;
            GetComponent<CapsuleCollider2D>().enabled = true;

            if (isMirror)
            {
                mirrorCounter += Time.deltaTime;
                if(mirrorCounter > mirrorOnTime + mirrorOffTime)
                {
                    mirrorCounter = 0;
                    mirrorActive = true;
                    gameObject.GetComponent<SpriteRenderer>().color = new Color(0.25f, 0.25f, 0.25f);
                }
                else if(mirrorCounter > mirrorOnTime)
                {
                    mirrorActive = false;
                    gameObject.GetComponent<SpriteRenderer>().color = new Color(0.75f, 0.75f, 0.75f);
                }
            }
            if (!myController.inRealWorld)
            {
                //target = GetComponent<Player>();
                float frac = Mathf.Log(pursuitFraction) * Time.deltaTime + 1;
                Vector3 targetPos = new Vector3(target.transform.position.x, target.transform.position.y, target.transform.position.z);
                transform.position = transform.position * (frac) + targetPos * (1 - frac);
                targetPos = targetPos - transform.position;
                float angle = Mathf.Atan2(targetPos.y, targetPos.x) * Mathf.Rad2Deg;
                transform.rotation = Quaternion.AngleAxis(angle - 90.0f, Vector3.forward);
                if (coolDownActive > 0)
                {
                    coolDownActive -= Time.deltaTime;
                }
                else
                {
                    fire();
                    coolDownActive = coolDown;
                }
            }
         }
    }

    protected void fire()
    {
        Projectile p = Instantiate(myProjectile);
        p.transform.position = transform.position;
        p.transform.rotation = transform.rotation;
        p.transform.Translate(0, 2.5f, 0, Space.Self);
        p.ySpeed = projectileSpeed;
        p.damage = projectileDamage;
        p.shooter = this.gameObject;

        p.xAccel = projectileCurve.x;
        p.yAccel = projectileCurve.y;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Projectile p = collision.gameObject.GetComponent<Projectile>();
        if(p != null)
        {
            Player pl = p.shooter.GetComponent<Player>();
            if(pl != null)
            {
                target = pl.gameObject;
            }
            if(mirrorActive)
            {
                p.xSpeed *= -1;
                p.ySpeed *= -1;
            }
            else
            {
                this.takeDamage(p.damage);
                Destroy(p.gameObject);
            } 
        }
    }
}
