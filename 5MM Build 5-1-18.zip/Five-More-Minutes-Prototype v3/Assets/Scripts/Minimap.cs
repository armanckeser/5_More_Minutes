﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class Minimap : MonoBehaviour {

	// Use this for initialization
	void Start () {
        this.transform.Translate(new Vector3(700, -10, 0));
        //AudioListener al = GetComponent<AudioListener>();
        //Destroy(al);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
