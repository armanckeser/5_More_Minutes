﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfHarmProjectile : Projectile {

    public Player myPlayer;
	// Use this for initialization
	void Start () {
        base.Start();
	}
	
	// Update is called once per frame
	void Update () {
        base.Update();
	}

    private void OnDestroy()
    {
        myPlayer.takeDamage(5);
    }
}
