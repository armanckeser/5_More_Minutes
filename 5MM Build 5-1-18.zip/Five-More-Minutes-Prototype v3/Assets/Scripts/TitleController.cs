﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TitleController : MonoBehaviour {

    public StartButton myButton;
    public StartButton tutorial;
    public Text myText;
    // Use this for initialization
    void Start () {
		myButton.GetComponentInChildren<Text>().text = "Just five more minutes!";
        tutorial.GetComponentInChildren<Text>().text = "New?  Play a tutorial!";
        myText.text = "Welcome to Five More Minutes!\n";
        myText.text += "Getting enough sleep is hard... help me out?";
    }
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
	}
}
